using System.Text.Json;
using DevTrack.Estructuras;
using DevTrack.Models;

namespace DevTrack.Data
{
    /// <summary>
    /// Módulo de seguimiento (Programador 2). Maneja los cambios de estado de las tareas y guarda:
    ///  - Cola (Queue): tareas esperando revisión QA.
    ///  - Pila (Stack): cambios de estado que se pueden deshacer.
    ///  - Lista enlazada: historial de movimientos.
    ///  - ListaDinamica: observaciones de los revisores.
    /// Se guarda en App_Data/seguimiento.json cada vez que hay un cambio.
    /// </summary>
    public class RepositorioSeguimiento
    {
        private readonly RepositorioDevTrack _repoBase;
        private readonly string _ruta;
        private readonly object _candado = new object();

        private readonly Cola<SolicitudRevision> _colaQA = new Cola<SolicitudRevision>();
        private readonly Pila<CambioEstado> _pilaDeshacer = new Pila<CambioEstado>();
        private readonly ListaEnlazada<RegistroHistorial> _historial = new ListaEnlazada<RegistroHistorial>();
        private readonly ListaDinamica<Observacion> _observaciones = new ListaDinamica<Observacion>();
        private int _siguienteIdObservacion = 1;

        private class DatosArchivo
        {
            public int SiguienteIdObservacion { get; set; } = 1;
            public SolicitudRevision[] ColaQA { get; set; } = Array.Empty<SolicitudRevision>();          // del frente al final
            public CambioEstado[] PilaDeshacer { get; set; } = Array.Empty<CambioEstado>();              // de la cima a la base
            public RegistroHistorial[] Historial { get; set; } = Array.Empty<RegistroHistorial>();       // el más reciente primero
            public Observacion[] Observaciones { get; set; } = Array.Empty<Observacion>();
        }

        public RepositorioSeguimiento(RepositorioDevTrack repoBase, IWebHostEnvironment entorno)
        {
            _repoBase = repoBase;

            string carpeta = Path.Combine(entorno.ContentRootPath, "App_Data");
            Directory.CreateDirectory(carpeta);
            _ruta = Path.Combine(carpeta, "seguimiento.json");

            Cargar();
            SincronizarCola();
        }

        // ---------------- CAMBIOS DE ESTADO ----------------

        /// <summary>Pendiente -> En desarrollo, o Rechazada -> En desarrollo (retomar).</summary>
        public Resultado IniciarTarea(int tareaId)
        {
            lock (_candado)
            {
                Tarea tarea = _repoBase.BuscarTarea(tareaId);
                if (tarea == null) return Resultado.Error("La tarea no existe.");

                if (!FlujoEstados.Permitido(tarea.Estado, EstadoTarea.EnDesarrollo))
                    return Resultado.Error($"Una tarea en estado \"{Visual.NombreEstado(tarea.Estado)}\" no puede pasar a En desarrollo.");

                string descripcion = tarea.Estado == EstadoTarea.Rechazada
                    ? "Retomada después del rechazo: pasó a En desarrollo"
                    : "Pasó de Pendiente a En desarrollo";

                AplicarCambio(tarea, EstadoTarea.EnDesarrollo, 0, descripcion);
                Guardar();
                return Resultado.Ok($"La tarea \"{tarea.Titulo}\" quedó En desarrollo.");
            }
        }

        /// <summary>En desarrollo -> En revisión QA. La tarea se mete al final de la cola.</summary>
        public Resultado EnviarARevision(int tareaId)
        {
            lock (_candado)
            {
                Tarea tarea = _repoBase.BuscarTarea(tareaId);
                if (tarea == null) return Resultado.Error("La tarea no existe.");

                if (!FlujoEstados.Permitido(tarea.Estado, EstadoTarea.EnRevisionQA))
                    return Resultado.Error("Solo se puede enviar a QA una tarea que esté En desarrollo.");

                _colaQA.Encolar(new SolicitudRevision { TareaId = tarea.Id, FechaEnvio = DateTime.Now });
                AplicarCambio(tarea, EstadoTarea.EnRevisionQA, 0, "Enviada a la cola de revisión QA");
                Guardar();
                return Resultado.Ok($"La tarea \"{tarea.Titulo}\" entró a la cola de QA en la posición {_colaQA.Cantidad}.");
            }
        }

        /// <summary>
        /// Revisa la tarea que está al frente de la cola: la aprueba o la rechaza y registra la observación.
        /// Se pide el Id de la tarea para asegurarse de que sigue siendo la primera de la cola.
        /// </summary>
        public Resultado ResolverRevision(int tareaId, bool aprobar, string revisor, string texto)
        {
            lock (_candado)
            {
                QuitarHuerfanas();

                if (_colaQA.EstaVacia)
                    return Resultado.Error("No hay tareas esperando revisión.");

                SolicitudRevision primera = _colaQA.VerFrente();
                if (primera.TareaId != tareaId)
                    return Resultado.Error("Esa tarea ya no es la siguiente de la cola. Actualiza la página.");

                if (string.IsNullOrWhiteSpace(revisor))
                    return Resultado.Error("Escribe el nombre de quien revisa.");

                if (!aprobar && string.IsNullOrWhiteSpace(texto))
                    return Resultado.Error("Para rechazar una tarea hay que explicar el motivo en la observación.");

                Tarea tarea = _repoBase.BuscarTarea(tareaId);
                EstadoTarea resultado = aprobar ? EstadoTarea.Aprobada : EstadoTarea.Rechazada;

                if (!FlujoEstados.Permitido(tarea.Estado, resultado))
                    return Resultado.Error("La tarea no está En revisión QA.");

                _colaQA.Desencolar();

                Observacion observacion = new Observacion
                {
                    Id = _siguienteIdObservacion++,
                    TareaId = tarea.Id,
                    TituloTarea = tarea.Titulo,
                    Revisor = revisor.Trim(),
                    Texto = string.IsNullOrWhiteSpace(texto) ? "" : texto.Trim(),
                    Decision = resultado,
                    Fecha = DateTime.Now
                };
                _observaciones.Agregar(observacion);

                string descripcion = aprobar
                    ? $"Aprobada por {observacion.Revisor}"
                    : $"Rechazada por {observacion.Revisor}";

                AplicarCambio(tarea, resultado, observacion.Id, descripcion);
                Guardar();

                return Resultado.Ok(aprobar
                    ? $"La tarea \"{tarea.Titulo}\" fue aprobada."
                    : $"La tarea \"{tarea.Titulo}\" fue rechazada y volverá a desarrollo.");
            }
        }

        /// <summary>Deshace el último cambio de estado (el que está en la cima de la pila).</summary>
        public Resultado Deshacer()
        {
            lock (_candado)
            {
                if (_pilaDeshacer.EstaVacia)
                    return Resultado.Error("No hay cambios para deshacer.");

                CambioEstado cambio = _pilaDeshacer.Desapilar();
                Tarea tarea = _repoBase.BuscarTarea(cambio.TareaId);

                if (tarea == null)
                {
                    Guardar();
                    return Resultado.Error($"La tarea \"{cambio.TituloTarea}\" ya no existe; se descartó ese cambio.");
                }

                // Si el cambio había metido la tarea a la cola, se saca de ahí.
                if (cambio.EstadoNuevo == EstadoTarea.EnRevisionQA)
                    _colaQA.EliminarDonde(s => s.TareaId == cambio.TareaId);

                // Si el cambio era una revisión, la tarea vuelve a la cola (al final) y se borra su observación.
                if (cambio.EstadoAnterior == EstadoTarea.EnRevisionQA)
                {
                    _colaQA.Encolar(new SolicitudRevision { TareaId = cambio.TareaId, FechaEnvio = DateTime.Now });
                    _observaciones.EliminarDonde(o => o.Id == cambio.ObservacionId);
                }

                _repoBase.CambiarEstadoTarea(tarea.Id, cambio.EstadoAnterior);

                AgregarHistorial(tarea,
                    $"Se deshizo el cambio: volvió de {Visual.NombreEstado(cambio.EstadoNuevo)} a {Visual.NombreEstado(cambio.EstadoAnterior)}");
                Guardar();

                return Resultado.Ok($"Se deshizo el cambio de \"{tarea.Titulo}\": volvió a {Visual.NombreEstado(cambio.EstadoAnterior)}.");
            }
        }

        // ---------------- CONSULTAS ----------------

        /// <summary>Tareas en espera de QA, de la primera a la última.</summary>
        public SolicitudRevision[] ObtenerCola()
        {
            lock (_candado)
            {
                QuitarHuerfanas();
                return _colaQA.ComoArreglo();
            }
        }

        /// <summary>Cambios que se pueden deshacer; el primero del arreglo es el que se deshace primero.</summary>
        public CambioEstado[] ObtenerPilaDeshacer()
        {
            lock (_candado) return _pilaDeshacer.ComoArreglo();
        }

        /// <summary>Historial de movimientos, del más reciente al más antiguo.</summary>
        public RegistroHistorial[] ObtenerHistorial()
        {
            lock (_candado) return _historial.ComoArreglo();
        }

        /// <summary>Todas las observaciones, de la más reciente a la más antigua.</summary>
        public Observacion[] ObtenerObservaciones()
        {
            lock (_candado)
            {
                Observacion[] todas = _observaciones.ComoArreglo();
                Array.Reverse(todas);
                return todas;
            }
        }

        // ---------------- AYUDAS INTERNAS ----------------

        /// <summary>Guarda el cambio en la pila y el historial, y cambia el estado de la tarea.</summary>
        private void AplicarCambio(Tarea tarea, EstadoTarea nuevoEstado, int idObservacion, string descripcion)
        {
            CambioEstado cambio = new CambioEstado
            {
                TareaId = tarea.Id,
                TituloTarea = tarea.Titulo,
                EstadoAnterior = tarea.Estado,
                EstadoNuevo = nuevoEstado,
                ObservacionId = idObservacion,
                Fecha = DateTime.Now
            };

            _pilaDeshacer.Apilar(cambio);
            AgregarHistorial(tarea, descripcion);
            _repoBase.CambiarEstadoTarea(tarea.Id, nuevoEstado);
        }

        private void AgregarHistorial(Tarea tarea, string descripcion)
        {
            _historial.AgregarAlInicio(new RegistroHistorial
            {
                Fecha = DateTime.Now,
                TareaId = tarea.Id,
                TituloTarea = tarea.Titulo,
                Descripcion = descripcion
            });
        }

        /// <summary>Si Alejandro eliminó una tarea (o su proyecto), se saca de la cola.</summary>
        private void QuitarHuerfanas()
        {
            _colaQA.EliminarDonde(s => _repoBase.BuscarTarea(s.TareaId) == null);
        }

        /// <summary>Toda tarea En revisión QA debe estar en la cola; si falta alguna, se agrega.</summary>
        private void SincronizarCola()
        {
            foreach (Tarea t in _repoBase.ObtenerTareas())
            {
                if (t.Estado == EstadoTarea.EnRevisionQA && !_colaQA.Contiene(s => s.TareaId == t.Id))
                    _colaQA.Encolar(new SolicitudRevision { TareaId = t.Id, FechaEnvio = DateTime.Now });
            }
        }

        // ---------------- PERSISTENCIA ----------------

        private void Guardar()
        {
            DatosArchivo datos = new DatosArchivo
            {
                SiguienteIdObservacion = _siguienteIdObservacion,
                ColaQA = _colaQA.ComoArreglo(),
                PilaDeshacer = _pilaDeshacer.ComoArreglo(),
                Historial = _historial.ComoArreglo(),
                Observaciones = _observaciones.ComoArreglo()
            };

            string json = JsonSerializer.Serialize(datos, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_ruta, json);
        }

        private void Cargar()
        {
            if (!File.Exists(_ruta)) return;

            try
            {
                string json = File.ReadAllText(_ruta);
                DatosArchivo datos = JsonSerializer.Deserialize<DatosArchivo>(json);
                if (datos == null) return;

                _siguienteIdObservacion = datos.SiguienteIdObservacion;

                foreach (SolicitudRevision s in datos.ColaQA) _colaQA.Encolar(s);

                // La pila viene de la cima a la base: se apila al revés para que quede en el mismo orden.
                for (int i = datos.PilaDeshacer.Length - 1; i >= 0; i--)
                    _pilaDeshacer.Apilar(datos.PilaDeshacer[i]);

                foreach (RegistroHistorial r in datos.Historial) _historial.AgregarAlFinal(r);
                foreach (Observacion o in datos.Observaciones) _observaciones.Agregar(o);
            }
            catch (JsonException)
            {
                // Archivo dañado: se empieza vacío en lugar de tumbar la aplicación.
                _colaQA.Limpiar();
                _pilaDeshacer.Limpiar();
                _historial.Limpiar();
                _observaciones.Limpiar();
            }
        }
    }
}
