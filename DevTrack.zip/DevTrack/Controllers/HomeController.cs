using DevTrack.Data;
using DevTrack.Estructuras;
using DevTrack.Models;
using Microsoft.AspNetCore.Mvc;

namespace DevTrack.Controllers
{
    public class HomeController : Controller
    {
        private readonly RepositorioDevTrack _repo;

        public HomeController(RepositorioDevTrack repo)
        {
            _repo = repo;
        }

        public IActionResult Index()
        {
            Tarea[] tareas = _repo.ObtenerTareas();
            int pendientes = 0, aprobadas = 0;
            ListaDinamica<TareaProxima> abiertas = new ListaDinamica<TareaProxima>();

            foreach (Tarea t in tareas)
            {
                if (t.Estado == EstadoTarea.Pendiente) pendientes++;

                if (t.Estado == EstadoTarea.Aprobada)
                {
                    aprobadas++;
                }
                else
                {
                    Proyecto p = _repo.BuscarProyecto(t.ProyectoId);
                    abiertas.Agregar(new TareaProxima
                    {
                        Tarea = t,
                        ProyectoId = t.ProyectoId,
                        NombreProyecto = p?.Nombre
                    });
                }
            }

            // Se ordenan por fecha de entrega y se toman las 6 más cercanas.
            TareaProxima[] ordenadas = abiertas.ComoArreglo();
            Array.Sort(ordenadas, (a, b) => a.Tarea.FechaEntrega.CompareTo(b.Tarea.FechaEntrega));

            int cantidad = Math.Min(6, ordenadas.Length);
            TareaProxima[] proximas = new TareaProxima[cantidad];
            for (int i = 0; i < cantidad; i++)
                proximas[i] = ordenadas[i];

            ResumenVM resumen = new ResumenVM
            {
                TotalProyectos = _repo.ObtenerProyectos().Length,
                TotalTareas = tareas.Length,
                TareasPendientes = pendientes,
                TareasAprobadas = aprobadas,
                Proximas = proximas
            };

            return View(resumen);
        }

        public IActionResult Error() => View();
    }
}
