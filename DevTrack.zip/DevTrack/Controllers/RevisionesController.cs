using DevTrack.Data;
using DevTrack.Estructuras;
using DevTrack.Models;
using Microsoft.AspNetCore.Mvc;

namespace DevTrack.Controllers
{
    public class RevisionesController : Controller
    {
        private readonly RepositorioDevTrack _repo;
        private readonly RepositorioSeguimiento _seguimiento;

        public RevisionesController(RepositorioDevTrack repo, RepositorioSeguimiento seguimiento)
        {
            _repo = repo;
            _seguimiento = seguimiento;
        }

        // GET /Revisiones
        public IActionResult Index()
        {
            SolicitudRevision[] cola = _seguimiento.ObtenerCola();
            ListaDinamica<ItemColaVM> items = new ListaDinamica<ItemColaVM>();

            for (int i = 0; i < cola.Length; i++)
            {
                Tarea tarea = _repo.BuscarTarea(cola[i].TareaId);
                if (tarea == null) continue;

                Proyecto proyecto = _repo.BuscarProyecto(tarea.ProyectoId);
                items.Agregar(new ItemColaVM
                {
                    Posicion = items.Cantidad + 1,
                    Tarea = tarea,
                    NombreProyecto = proyecto?.Nombre,
                    FechaEnvio = cola[i].FechaEnvio
                });
            }

            // Solo se muestran las 8 observaciones más recientes.
            Observacion[] todas = _seguimiento.ObtenerObservaciones();
            int cantidad = Math.Min(8, todas.Length);
            Observacion[] recientes = new Observacion[cantidad];
            for (int i = 0; i < cantidad; i++)
                recientes[i] = todas[i];

            ViewBag.Revisor = TempData["Revisor"];

            return View(new RevisionVM { Cola = items.ComoArreglo(), Observaciones = recientes });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Resolver(int tareaId, string decision, string revisor, string observacion)
        {
            bool aprobar = decision == "aprobar";
            Resultado resultado = _seguimiento.ResolverRevision(tareaId, aprobar, revisor, observacion);

            TempData[resultado.Exito ? "Mensaje" : "Error"] = resultado.Mensaje;
            TempData["Revisor"] = revisor;   // para no volver a escribir el nombre
            return RedirectToAction(nameof(Index));
        }
    }
}
