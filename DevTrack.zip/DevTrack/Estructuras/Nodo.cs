namespace DevTrack.Estructuras
{
    /// <summary>
    /// Un nodo guarda un dato y apunta al siguiente nodo.
    /// Con nodos enlazados se construyen la Cola, la Pila y la Lista enlazada.
    /// </summary>
    public class Nodo<T>
    {
        public T Dato;
        public Nodo<T> Siguiente;

        public Nodo(T dato)
        {
            Dato = dato;
            Siguiente = null;
        }
    }
}
