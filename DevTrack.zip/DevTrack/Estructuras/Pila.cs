namespace DevTrack.Estructuras
{
    /// <summary>
    /// Pila (Stack): el último que entra es el primero que sale (LIFO).
    /// DevTrack la usa para "deshacer": el último cambio hecho es el primero que se deshace.
    /// </summary>
    public class Pila<T>
    {
        private Nodo<T> _cima;   // el elemento de arriba
        private int _cantidad;

        public int Cantidad => _cantidad;
        public bool EstaVacia => _cima == null;

        /// <summary>Pone un elemento arriba de la pila (push).</summary>
        public void Apilar(T elemento)
        {
            Nodo<T> nuevo = new Nodo<T>(elemento);
            nuevo.Siguiente = _cima;   // el nuevo apunta al que estaba arriba
            _cima = nuevo;
            _cantidad++;
        }

        /// <summary>Saca y devuelve el elemento de arriba (pop).</summary>
        public T Desapilar()
        {
            if (_cima == null)
                throw new InvalidOperationException("La pila está vacía.");

            T dato = _cima.Dato;
            _cima = _cima.Siguiente;
            _cantidad--;
            return dato;
        }

        /// <summary>Devuelve el elemento de arriba sin sacarlo (peek).</summary>
        public T VerCima()
        {
            if (_cima == null)
                throw new InvalidOperationException("La pila está vacía.");

            return _cima.Dato;
        }

        /// <summary>Copia la pila a un arreglo, empezando por la cima.</summary>
        public T[] ComoArreglo()
        {
            T[] copia = new T[_cantidad];
            Nodo<T> actual = _cima;
            int i = 0;
            while (actual != null)
            {
                copia[i] = actual.Dato;
                i++;
                actual = actual.Siguiente;
            }
            return copia;
        }

        public void Limpiar()
        {
            _cima = null;
            _cantidad = 0;
        }
    }
}
