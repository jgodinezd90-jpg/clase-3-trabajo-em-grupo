using System.Collections;

namespace DevTrack.Estructuras
{
    /// <summary>
    /// Lista dinámica genérica implementada sobre un ARREGLO.
    /// Cuando el arreglo se llena, se crea uno del doble de tamaño y se copian los elementos.
    /// Es la estructura que usa DevTrack para almacenar proyectos y tareas.
    /// </summary>
    public class ListaDinamica<T> : IEnumerable<T>
    {
        private T[] _elementos;
        private int _cantidad;

        public ListaDinamica(int capacidadInicial = 4)
        {
            if (capacidadInicial < 1) capacidadInicial = 1;
            _elementos = new T[capacidadInicial];
            _cantidad = 0;
        }

        public int Cantidad => _cantidad;

        public T this[int indice]
        {
            get
            {
                ValidarIndice(indice);
                return _elementos[indice];
            }
            set
            {
                ValidarIndice(indice);
                _elementos[indice] = value;
            }
        }

        /// <summary>Agrega al final. O(1) amortizado.</summary>
        public void Agregar(T elemento)
        {
            if (_cantidad == _elementos.Length)
                Redimensionar(_elementos.Length * 2);

            _elementos[_cantidad] = elemento;
            _cantidad++;
        }

        /// <summary>Elimina el elemento en la posición indicada y corre los siguientes a la izquierda. O(n).</summary>
        public void EliminarEn(int indice)
        {
            ValidarIndice(indice);

            for (int i = indice; i < _cantidad - 1; i++)
                _elementos[i] = _elementos[i + 1];

            _elementos[_cantidad - 1] = default;
            _cantidad--;
        }

        /// <summary>Busca linealmente el primer elemento que cumpla la condición. Devuelve -1 si no existe.</summary>
        public int IndiceDe(Func<T, bool> condicion)
        {
            for (int i = 0; i < _cantidad; i++)
            {
                if (condicion(_elementos[i]))
                    return i;
            }
            return -1;
        }

        public T Buscar(Func<T, bool> condicion)
        {
            int indice = IndiceDe(condicion);
            return indice >= 0 ? _elementos[indice] : default;
        }

        /// <summary>Elimina todos los elementos que cumplan la condición. Devuelve cuántos eliminó.</summary>
        public int EliminarDonde(Func<T, bool> condicion)
        {
            int escritura = 0;
            int eliminados = 0;

            for (int lectura = 0; lectura < _cantidad; lectura++)
            {
                if (condicion(_elementos[lectura]))
                {
                    eliminados++;
                }
                else
                {
                    _elementos[escritura] = _elementos[lectura];
                    escritura++;
                }
            }

            for (int i = escritura; i < _cantidad; i++)
                _elementos[i] = default;

            _cantidad = escritura;
            return eliminados;
        }

        public void Limpiar()
        {
            for (int i = 0; i < _cantidad; i++)
                _elementos[i] = default;
            _cantidad = 0;
        }

        /// <summary>Copia el contenido a un arreglo exacto (útil para guardar en JSON).</summary>
        public T[] ComoArreglo()
        {
            T[] copia = new T[_cantidad];
            for (int i = 0; i < _cantidad; i++)
                copia[i] = _elementos[i];
            return copia;
        }

        private void Redimensionar(int nuevaCapacidad)
        {
            T[] nuevo = new T[nuevaCapacidad];
            for (int i = 0; i < _cantidad; i++)
                nuevo[i] = _elementos[i];
            _elementos = nuevo;
        }

        private void ValidarIndice(int indice)
        {
            if (indice < 0 || indice >= _cantidad)
                throw new IndexOutOfRangeException($"Índice {indice} fuera de rango (cantidad: {_cantidad}).");
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < _cantidad; i++)
                yield return _elementos[i];
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
