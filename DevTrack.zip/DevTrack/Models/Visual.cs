namespace DevTrack.Models
{
    /// <summary>Utilidades para la parte visual: colores por proyecto/persona, iniciales y fechas legibles.</summary>
    public static class Visual
    {
        private static readonly string[] Paleta =
            { "cobalto", "menta", "ambar", "coral", "violeta", "turquesa" };

        public static string ColorProyecto(int id) => Paleta[Math.Abs(id) % Paleta.Length];

        public static string ColorPersona(string nombre)
        {
            int suma = 0;
            foreach (char c in nombre ?? "")
                suma += c;
            return Paleta[suma % Paleta.Length];
        }

        public static string Iniciales(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre)) return "?";

            string[] partes = nombre.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (partes.Length == 1)
                return partes[0].Substring(0, Math.Min(2, partes[0].Length)).ToUpper();

            return (partes[0][0].ToString() + partes[1][0]).ToUpper();
        }

        public static string NombreEstado(EstadoTarea estado)
        {
            switch (estado)
            {
                case EstadoTarea.Pendiente: return "Pendiente";
                case EstadoTarea.EnDesarrollo: return "En desarrollo";
                case EstadoTarea.EnRevisionQA: return "En revisión QA";
                case EstadoTarea.Aprobada: return "Aprobada";
                case EstadoTarea.Rechazada: return "Rechazada";
                default: return estado.ToString();
            }
        }

        public static int Porcentaje(int parte, int total)
        {
            return total == 0 ? 0 : (int)Math.Round(parte * 100.0 / total);
        }

        public static int DiasRestantes(DateTime fecha)
        {
            return (int)(fecha.Date - DateTime.Today).TotalDays;
        }

        public static string TextoPlazo(DateTime fecha)
        {
            int dias = DiasRestantes(fecha);
            if (dias == 0) return "Vence hoy";
            if (dias == 1) return "Vence mañana";
            if (dias > 1) return $"Vence en {dias} días";
            if (dias == -1) return "Venció ayer";
            return $"Venció hace {-dias} días";
        }
    }
}
