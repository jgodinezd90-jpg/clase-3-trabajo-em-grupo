using System.ComponentModel.DataAnnotations;

namespace DevTrack.Models
{
    public enum Prioridad
    {
        Baja = 1,
        Media = 2,
        Alta = 3,
        Critica = 4
    }

    public enum EstadoTarea
    {
        Pendiente = 1,
        [Display(Name = "En desarrollo")]
        EnDesarrollo = 2,
        [Display(Name = "En revisión QA")]
        EnRevisionQA = 3,
        Aprobada = 4,
        Rechazada = 5
    }
}
