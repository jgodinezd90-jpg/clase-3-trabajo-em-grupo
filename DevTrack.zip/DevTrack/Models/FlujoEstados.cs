namespace DevTrack.Models
{
    /// <summary>
    /// Reglas de a qué estado puede pasar una tarea:
    /// Pendiente -> En desarrollo -> En revisión QA -> Aprobada o Rechazada.
    /// Una tarea Rechazada vuelve a En desarrollo. Aprobada es el final.
    /// </summary>
    public static class FlujoEstados
    {
        public static bool Permitido(EstadoTarea desde, EstadoTarea hacia)
        {
            switch (desde)
            {
                case EstadoTarea.Pendiente:
                    return hacia == EstadoTarea.EnDesarrollo;
                case EstadoTarea.EnDesarrollo:
                    return hacia == EstadoTarea.EnRevisionQA;
                case EstadoTarea.EnRevisionQA:
                    return hacia == EstadoTarea.Aprobada || hacia == EstadoTarea.Rechazada;
                case EstadoTarea.Rechazada:
                    return hacia == EstadoTarea.EnDesarrollo;
                default:
                    return false;
            }
        }
    }
}
