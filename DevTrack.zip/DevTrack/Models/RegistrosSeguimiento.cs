namespace DevTrack.Models
{
    /// <summary>Resultado simple de una operación: si salió bien y un mensaje para mostrar.</summary>
    public class Resultado
    {
        public bool Exito { get; set; }
        public string Mensaje { get; set; }

        public static Resultado Ok(string mensaje) => new Resultado { Exito = true, Mensaje = mensaje };
        public static Resultado Error(string mensaje) => new Resultado { Exito = false, Mensaje = mensaje };
    }

    /// <summary>Una tarea esperando en la cola de revisión QA.</summary>
    public class SolicitudRevision
    {
        public int TareaId { get; set; }
        public DateTime FechaEnvio { get; set; }
    }

    /// <summary>Un cambio de estado guardado en la pila para poder deshacerlo.</summary>
    public class CambioEstado
    {
        public int TareaId { get; set; }
        public string TituloTarea { get; set; }
        public EstadoTarea EstadoAnterior { get; set; }
        public EstadoTarea EstadoNuevo { get; set; }
        // Si el cambio fue una revisión, aquí va el Id de su observación (0 si no hubo).
        public int ObservacionId { get; set; }
        public DateTime Fecha { get; set; }
    }

    /// <summary>Una línea del historial de movimientos (lista enlazada).</summary>
    public class RegistroHistorial
    {
        public DateTime Fecha { get; set; }
        public int TareaId { get; set; }
        public string TituloTarea { get; set; }
        public string Descripcion { get; set; }
    }

    /// <summary>Comentario que deja el revisor al aprobar o rechazar una tarea.</summary>
    public class Observacion
    {
        public int Id { get; set; }
        public int TareaId { get; set; }
        public string TituloTarea { get; set; }
        public string Revisor { get; set; }
        public string Texto { get; set; }
        public EstadoTarea Decision { get; set; }   // Aprobada o Rechazada
        public DateTime Fecha { get; set; }
    }
}
